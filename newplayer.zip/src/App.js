import React, { useEffect, useRef } from 'react';
import VideoPlayer from './VideoPlayer';

function App() {


  return (
    <div>
      <VideoPlayer/>
  </div>
  );
}

export default App;
