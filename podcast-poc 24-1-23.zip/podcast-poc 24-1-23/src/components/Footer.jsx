import React from 'react'

export default function Footer() {
  return (
    <div className='footer text-sm'>&copy; 2023. All Rights Reserved. Powered by Unilever Podcasts</div>
  )
}
