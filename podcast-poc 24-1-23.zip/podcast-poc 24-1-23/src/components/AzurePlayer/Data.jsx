const songs = [   
    {
      id :1,
      title: "Podcast 1",
      src: "https://dev1mediaservice.streaming.mediaservices.windows.net/5acf9393-5883-4d7b-8d68-c9a8b495ecd1/5ffb03fe-450e-40d6-88d9-e46e8dc8.ism/manifest",
     
    },
    {
      id: 2,
      title: "Podcast 2",
      src: "https://dev1mediaservice.streaming.mediaservices.windows.net/4a805639-5a0f-4c45-b9f9-1dade22c74c7/cbef2bb0-54b8-4dc7-b8e9-e0ba5e1b.ism/manifest",
      
    },
    {
      id: 3,
      title: "Podcast 3",
      src: "https://dev1mediaservice.streaming.mediaservices.windows.net/fe6c211e-9998-44d8-9a3a-3f76f1e87190/8ef1d825-89ce-456f-aae6-5bd7250c.ism/manifest",
    },
  ];
  
  export default songs;

  