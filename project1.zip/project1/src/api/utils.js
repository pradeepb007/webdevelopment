//Common 

const apiUrl = "http://localhost:4000";

export {apiUrl};