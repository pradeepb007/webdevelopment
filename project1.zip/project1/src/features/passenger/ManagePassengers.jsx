import React,{useEffect} from 'react'
import { Container } from "@mui/system";
import Typography from "@mui/material/Typography";
import { apiUrl } from "../../api/utils";
import axios from "axios";
import { useDispatch } from "react-redux";


import styles from "./Passengers.module.scss";
import Passengers from './Passengers';
import { getPassengers } from './passengerSlice';
import { getFlightID, getSingleFlight } from '../flights/flightSlice';

function ManagePassengerPage() {

  const dispatch = useDispatch();

  useEffect(()=>{
    const fetchPassengers = async () =>{
      const response = await axios.get(`${apiUrl}/passengers`)   
      .catch((error)=>{
        console.log("error", error);
      })
      console.log("The response from API", response);
      dispatch(getPassengers(response.data));
    }
  fetchPassengers();

  
  },[dispatch])

  useEffect(()=>{
    const fetchSelectedFlight = async () =>{
    //  const response = await axios.get(`${apiUrl}/flights/${getFlightID}`)   
      const response = await axios.get(`${apiUrl}/flights/1`)
      .catch((error)=>{
        console.log("error", error);
      })
      console.log("The response from API", response);
      dispatch(getSingleFlight(response.data));
    }
    fetchSelectedFlight();

  
  },[dispatch])




  return (
    <>
     <Container maxWidth="xl">    
     <div className={styles.pageHeader}>
        <Typography variant="h5" component="h2" className={styles.pageHeading}>
          Manage Passengers
        </Typography>
        <button> Create Passenger</button>
      </div>
      <div className={styles.flightDetails}>
        <Typography variant="h5" component="h3">
         Flight Information
        </Typography>

              Airline: IndiGo
              Flight No: 1234
              Source: Hyderabad
              Destination: Bangalore
              DEP Date: 2023-05-15
              DEP Time : 22:00
              AVR Date: 2023-05-15
              AVR Time : 23:55

      </div>
      <Passengers/>


    
      </Container>
    </>
  )
}

export default ManagePassengerPage