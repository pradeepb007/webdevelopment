import React from 'react'

function CheckInPassengers() {
  return (
    <div>CheckInPassengers</div>
  )
}

export default CheckInPassengers