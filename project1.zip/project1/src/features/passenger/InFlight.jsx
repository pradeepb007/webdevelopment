import React from 'react'

function InFlight() {
  return (
    <div>InFlight</div>
  )
}

export default InFlight