import React from "react";
import SharePodcast from "./SharePodcast";

function Controls(props) {
  return (
    <div className="c-player--controls">
      <button className="skip-btn" onClick={() => props.SkipSong(false)}>
        Previous
      </button>
      <button className="skip-btn" onClick={() => props.SkipSong()}>
        Next
      </button>

      
      
    </div>
  );
}

export default Controls;