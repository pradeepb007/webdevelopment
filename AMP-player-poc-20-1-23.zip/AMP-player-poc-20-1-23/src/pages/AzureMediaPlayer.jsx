import React, { useState, useEffect, useRef } from "react";

export default function AzureMediaPlayer() {
  let amp = window["amp"];

  // const [duration, setDuration] = useState(0);

  // const backThirty = () => {    
  //   amp.plugin('timelineMarker', function (options) {
  //     console.log("pluginclass");
  //     var player = this;
  //     player.addEventListener(amp.eventName.durationchange, function () {
  //     duration  = player.duration();
  //     var progressControlSlider = getElementsByClassName("vjs-progress-control", "vjs-slider");
  //     function getElementsByClassName(className, childClass) {
  //         var elements = document.getElementById("azuremediaplayer").getElementsByClassName(className);
  //         var matches = [];

  //         function traverse(node) {
  //             if (node && node.childNodes) {
  //                 for (var i = 0; i < node.childNodes.length; i++) {
  //                     if (node.childNodes[i].childNodes.length > 0) {
  //                         traverse(node.childNodes[i]);
  //                     }

  //                     if (node.childNodes[i].getAttribute && node.childNodes[i].getAttribute('class')) {
  //                         if (node.childNodes[i].getAttribute('class').split(" ").indexOf(childClass) >= 0) {
  //                             matches.push(node.childNodes[i]);
  //                         }
  //                     }
  //                 }
  //             }
  //         }
  //         if (!childClass)
  //             return elements && elements.length > 0 ? elements[0] : null;

  //         if (elements && elements.length > 0) {
  //             for (var i = 0; i < elements.length; i++)
  //                 traverse(elements[i]);
  //         }
  //         return matches && matches.length > 0 ? matches[0] : null;
  //     }

  //     if (progressControlSlider) {
  //         for (var index = 0; index < options.markertime.length; index++) {
  //             var marker = options.markertime[index];               
  //             if (marker) {
  //                 var secs = convertTimeFormatToSecs(marker);
  //                 if (secs >= 0 && secs <= duration) {
  //                     var markerLeftPosition = (secs / duration * 100);
  //                     var div = document.createElement('div');
  //                     div.className = "amp-timeline-marker";
  //                     div.style.left = markerLeftPosition + "%";
  //                     div.innerHTML = "&nbsp;&nbsp;"
  //                     progressControlSlider.appendChild(div);
  //                 }
  //             }
  //         }
  //     }
  // });

 

  //     function convertTimeFormatToSecs(timeFormat) {
  //         if (timeFormat) {
  //             var timeFragments = timeFormat.split(":");
  //             if (timeFragments.length > 0) {
  //                 switch (timeFragments.length) {
  //                     case 4: return (parseInt(timeFragments[0], 10) * 60 * 60) + (parseInt(timeFragments[1], 10) * 60) + parseInt(timeFragments[2], 10) + (timeFragments[3] / 100);
  //                     case 3: return (parseInt(timeFragments[0], 10) * 60 * 60) + (parseInt(timeFragments[1], 10) * 60) + parseInt(timeFragments[2], 10);
  //                     case 2: return parseInt(timeFragments[0], 10) * 60 + parseInt(timeFragments[1], 10);
  //                     case 1: return parseInt(timeFragments[0], 10);
  //                     default: return parseInt(timeFragments[0], 10);
  //                 }
  //             }
  //             else
  //                 return parseInt(timeFormat, 10);
  //         }

  //         return 0;
  //     }

  
     

  // });
   
  // }



  const videoElement = useRef();
  const myOptions = {
    nativeControlsForTouch: true,
    controls: true,
    autoplay: true,
    width: "640",
    height: "400",
    playbackSpeed: {
      enabled: true,
      initialSpeed: 1.0,
      speedLevels: [
          { name: "x4.0", value: 4.0 },
          { name: "x3.0", value: 3.0 },
          { name: "x2.0", value: 2.0 },
          { name: "x1.75", value: 1.75 },
          { name: "x1.5", value: 1.5 },
          { name: "x1.25", value: 1.25 },
          { name: "normal", value: 1.0 },
          { name: "x0.75", value: 0.75 },
          { name: "x0.5", value: 0.5 },
      ]
  },
  // plugins: {
  //   timelineMarker: {
  //     markertime: ["0:00","0:10", "0:20"]      
  //   }
  // }
  };
  useEffect(() => {
    if (videoElement.current) {
      const myPlayer = amp(videoElement.current, myOptions);
      myPlayer.src([
        {
          src: "https://dev1mediaservice.streaming.mediaservices.windows.net/5acf9393-5883-4d7b-8d68-c9a8b495ecd1/5ffb03fe-450e-40d6-88d9-e46e8dc8.ism/manifest",
          type: "application/vnd.ms-sstr+xml",
        //   ProtectionInfo : [
        //     {
        //       type : "AES",
        //       authenticationToken: mediaToken?.Cotent,
        //   }
        // ]
        },
      ]);
     console.log("Video Element is: ", videoElement.current);
    }
    
  }, [videoElement]);

  return (
    <div className="main-container">

      <podcastItems/>
     <video
        ref={videoElement}   
        id="azuremediaplayer"     
        class="azuremediaplayer amp-default-skin amp-big-play-centered"
        tabindex="0"
      ></video> 


    </div>
  );
}
